SVG INVENTORY ICONS
===================

SVG Inventory Icons is a graphic library which contains icons in SVG 1.0 format. Each icon is defined as simple as possible. Unnecessary data are removed: transform operations, unused tags or more than two digits after the comma. All the icons are defined in the same way thanks to the tags: width="100%" height="100%" viewBox="0 0 48 48"

COPYRIGHT AND LICENSE
=====================

All icons in the library are released under the GNU GPL version 3. Later versions are permitted.

LINKS
=====

Homepage  http://poufpoufproduction.fr
Source    https://github.com/PoufPoufProduction/SVG-Inventory-Icons
Email     johannc@poufpoufproduction.fr
